# 🛠️ Audio Requests

Jimmy's commissioning log for missing audio assets.
**Format:** `[Date] | Requester | [Asset Name] | [Description] | Priority | [Status]`

| Date | Requester | Asset Name | Description | Priority | Status |
|------|-----------|------------|-------------|----------|--------|
| 2026-06-08 | Jimmy | UI_PARCHMENT_OPEN | [Sunny Prompt]: High-quality fantasy UI: crisp parchment scroll unrolling. Tactile mid-high crinkling, quick transient, dry texture. | High | Ready |
| 2026-06-08 | Jimmy | UI_PARCHMENT_CLOSE | [Sunny Prompt]: High-quality fantasy UI: parchment scroll rolling shut. Short decisive friction, light paper thud, tactile rustle. | Low | Ready |
| 2026-06-08 | Jimmy | UI_CHARACTER_SELECT | [Sunny Prompt]: Minimal fantasy UI: light organic thud of a wooden miniature or heavy parchment tab. Crystalline clarity, warm resonance. | Medium | Ready |
| 2026-06-08 | Jimmy | UI_ARMORY_OPEN | [Sunny Prompt]: Heavy cinematic SFX: large mechanical lock disengaging, slow groan of a stone portal. Deep low-end, metallic clinks. | High | Ready |
| 2026-06-08 | Jimmy | DICE_ROLL_WOOD | [Sunny Prompt]: Physics-based SFX: multiple polyhedral dice rolling on solid oak. Varied impact, sharp resin clacks, natural dispersion. | High | Ready |
| 2026-06-08 | Jimmy | DICE_CRIT_SUCCESS | [Sunny Prompt]: Magical UI Sting: triumphant crystalline chime with subtle arcane flare. High-frequency shimmer, rewarding tonality. | High | Ready |
| 2026-06-08 | Jimmy | UI_PAGE_TURN | [Sunny Prompt]: Tactile SFX: heavy slow flip of a large vellum page. Deep paper rustle, binding flex, immersive fiber textures. | Medium | Ready |
| 2026-06-08 | Jimmy | UI_MAP_TOKEN_MOVE | [Sunny Prompt]: Organic SFX: solid wooden thud and slide on parchment. Short, dry, clear wood-on-paper friction. | Medium | Ready |

# Get generated items

GET https://api.elevenlabs.io/v1/history

Returns a list of your generated audio.

Reference: https://elevenlabs.io/docs/api-reference/history/list

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: api
  version: 1.0.0
paths:
  /v1/history:
    get:
      operationId: list
      summary: Get generated items
      description: Returns a list of your generated audio.
      tags:
        - subpackage_history
      parameters:
        - name: page_size
          in: query
          description: >-
            How many history items to return at maximum. Can not exceed 1000,
            defaults to 100.
          required: false
          schema:
            type: integer
            default: 100
        - name: start_after_history_item_id
          in: query
          description: >-
            After which ID to start fetching, use this parameter to paginate
            across a large collection of history items. In case this parameter
            is not provided history items will be fetched starting from the most
            recently created one ordered descending by their creation date.
          required: false
          schema:
            type:
              - string
              - 'null'
        - name: voice_id
          in: query
          description: >-
            ID of the voice to be filtered for. You can use the [Get
            voices](/docs/api-reference/voices/search) endpoint list all the
            available voices.
          required: false
          schema:
            type:
              - string
              - 'null'
        - name: model_id
          in: query
          description: >-
            Search term used for filtering history items. If provided, source
            becomes required.
          required: false
          schema:
            type:
              - string
              - 'null'
        - name: date_before_unix
          in: query
          description: Unix timestamp to filter history items before this date (exclusive).
          required: false
          schema:
            type:
              - integer
              - 'null'
        - name: date_after_unix
          in: query
          description: Unix timestamp to filter history items after this date (inclusive).
          required: false
          schema:
            type:
              - integer
              - 'null'
        - name: sort_direction
          in: query
          description: Sort direction for the results.
          required: false
          schema:
            oneOf:
              - $ref: '#/components/schemas/V1HistoryGetParametersSortDirectionSchema'
              - type: 'null'
            default: desc
        - name: search
          in: query
          description: search term used for filtering
          required: false
          schema:
            type:
              - string
              - 'null'
        - name: source
          in: query
          description: Source of the generated history item
          required: false
          schema:
            oneOf:
              - $ref: '#/components/schemas/V1HistoryGetParametersSourceSchema'
              - type: 'null'
        - name: xi-api-key
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/GetSpeechHistoryResponseModel'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
servers:
  - url: https://api.elevenlabs.io
  - url: https://api.us.elevenlabs.io
  - url: https://api.eu.residency.elevenlabs.io
  - url: https://api.in.residency.elevenlabs.io
components:
  schemas:
    V1HistoryGetParametersSortDirectionSchema:
      type: string
      enum:
        - asc
        - desc
      default: desc
      description: Sort direction for the results.
      title: V1HistoryGetParametersSortDirectionSchema
    V1HistoryGetParametersSourceSchema:
      type: string
      enum:
        - TTS
        - STS
      description: Source of the generated history item
      title: V1HistoryGetParametersSourceSchema
    SpeechHistoryItemResponseModelVoiceCategory:
      type: string
      enum:
        - premade
        - cloned
        - generated
        - professional
      description: >-
        The category of the voice. Either 'premade', 'cloned', 'generated' or
        'professional'.
      title: SpeechHistoryItemResponseModelVoiceCategory
    FeedbackResponseModel:
      type: object
      properties:
        thumbs_up:
          type: boolean
          description: Whether the user liked the generated item.
        feedback:
          type: string
          description: The feedback text provided by the user.
        emotions:
          type: boolean
          description: Whether the user provided emotions.
        inaccurate_clone:
          type: boolean
          description: Whether the user thinks the clone is inaccurate.
        glitches:
          type: boolean
          description: Whether the user thinks there are glitches in the audio.
        audio_quality:
          type: boolean
          description: Whether the user thinks the audio quality is good.
        other:
          type: boolean
          description: Whether the user provided other feedback.
        review_status:
          type: string
          default: not_reviewed
          description: The review status of the item. Defaults to 'not_reviewed'.
      required:
        - thumbs_up
        - feedback
        - emotions
        - inaccurate_clone
        - glitches
        - audio_quality
        - other
      title: FeedbackResponseModel
    SpeechHistoryItemResponseModelSource:
      type: string
      enum:
        - TTS
        - STS
        - Projects
        - PD
        - AN
        - Dubbing
        - PlayAPI
        - ConvAI
        - VoiceGeneration
        - InVPC
      description: >-
        The source of the history item. Either TTS (text to speech), STS (speech
        to text), AN (audio native), Projects, Dubbing, PlayAPI, PD
        (pronunciation dictionary) or ConvAI (Agents Platform).
      title: SpeechHistoryItemResponseModelSource
    HistoryAlignmentResponseModel:
      type: object
      properties:
        characters:
          type: array
          items:
            type: string
          description: The characters in the alignment.
        character_start_times_seconds:
          type: array
          items:
            type: number
            format: double
          description: The start times of the characters in seconds.
        character_end_times_seconds:
          type: array
          items:
            type: number
            format: double
          description: The end times of the characters in seconds.
      required:
        - characters
        - character_start_times_seconds
        - character_end_times_seconds
      title: HistoryAlignmentResponseModel
    HistoryAlignmentsResponseModel:
      type: object
      properties:
        alignment:
          $ref: '#/components/schemas/HistoryAlignmentResponseModel'
          description: The alignment of the text.
        normalized_alignment:
          $ref: '#/components/schemas/HistoryAlignmentResponseModel'
          description: The normalized alignment of the text.
      required:
        - alignment
        - normalized_alignment
      title: HistoryAlignmentsResponseModel
    DialogueInputResponseModel:
      type: object
      properties:
        text:
          type: string
          description: The text of the dialogue input line.
        voice_id:
          type: string
          description: The ID of the voice used for this dialogue input line.
        voice_name:
          type: string
          description: The name of the voice used for this dialogue input line.
      required:
        - text
        - voice_id
        - voice_name
      title: DialogueInputResponseModel
    SpeechHistoryItemResponseModel:
      type: object
      properties:
        history_item_id:
          type: string
          description: The ID of the history item.
        request_id:
          type:
            - string
            - 'null'
          description: The ID of the request.
        voice_id:
          type:
            - string
            - 'null'
          description: The ID of the voice used.
        model_id:
          type:
            - string
            - 'null'
          description: The ID of the model.
        voice_name:
          type:
            - string
            - 'null'
          description: The name of the voice.
        voice_category:
          oneOf:
            - $ref: '#/components/schemas/SpeechHistoryItemResponseModelVoiceCategory'
            - type: 'null'
          description: >-
            The category of the voice. Either 'premade', 'cloned', 'generated'
            or 'professional'.
        text:
          type:
            - string
            - 'null'
          description: The text used to generate the audio item.
        date_unix:
          type: integer
          description: Unix timestamp of when the item was created.
        character_count_change_from:
          type: integer
          description: The character count change from.
        character_count_change_to:
          type: integer
          description: The character count change to.
        content_type:
          type: string
          description: The content type of the generated item.
        state:
          description: Any type
        settings:
          type:
            - object
            - 'null'
          additionalProperties:
            description: Any type
          description: The settings of the history item.
        feedback:
          oneOf:
            - $ref: '#/components/schemas/FeedbackResponseModel'
            - type: 'null'
          description: >-
            Feedback associated with the generated item. Returns null if no
            feedback has been provided.
        share_link_id:
          type:
            - string
            - 'null'
          description: The ID of the share link.
        source:
          oneOf:
            - $ref: '#/components/schemas/SpeechHistoryItemResponseModelSource'
            - type: 'null'
          description: >-
            The source of the history item. Either TTS (text to speech), STS
            (speech to text), AN (audio native), Projects, Dubbing, PlayAPI, PD
            (pronunciation dictionary) or ConvAI (Agents Platform).
        alignments:
          oneOf:
            - $ref: '#/components/schemas/HistoryAlignmentsResponseModel'
            - type: 'null'
          description: The alignments of the history item.
        dialogue:
          type:
            - array
            - 'null'
          items:
            $ref: '#/components/schemas/DialogueInputResponseModel'
          description: >-
            The dialogue (voice and text pairs) used to generate the audio item.
            If this is set then the top level `text` and `voice_id` fields will
            be empty.
        output_format:
          type:
            - string
            - 'null'
          description: The output format the audio was originally generated in.
      required:
        - history_item_id
        - date_unix
        - character_count_change_from
        - character_count_change_to
        - content_type
        - state
      title: SpeechHistoryItemResponseModel
    GetSpeechHistoryResponseModel:
      type: object
      properties:
        history:
          type: array
          items:
            $ref: '#/components/schemas/SpeechHistoryItemResponseModel'
          description: A list of speech history items.
        last_history_item_id:
          type:
            - string
            - 'null'
          description: The ID of the last history item.
        has_more:
          type: boolean
          description: Whether there are more history items to fetch.
        scanned_until:
          type:
            - integer
            - 'null'
          description: The timestamp of the last history item.
      required:
        - history
        - has_more
      title: GetSpeechHistoryResponseModel
    ValidationErrorLocItems:
      oneOf:
        - type: string
        - type: integer
      title: ValidationErrorLocItems
    ValidationError:
      type: object
      properties:
        loc:
          type: array
          items:
            $ref: '#/components/schemas/ValidationErrorLocItems'
        msg:
          type: string
        type:
          type: string
      required:
        - loc
        - msg
        - type
      title: ValidationError
    HTTPValidationError:
      type: object
      properties:
        detail:
          type: array
          items:
            $ref: '#/components/schemas/ValidationError'
      title: HTTPValidationError

```

## SDK Code Examples

```typescript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";

async function main() {
    const client = new ElevenLabsClient();
    await client.history.list({});
}
main();

```

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

client.history.list()

```

```go
package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {

	url := "https://api.elevenlabs.io/v1/history"

	req, _ := http.NewRequest("GET", url, nil)

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://api.elevenlabs.io/v1/history")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Get.new(url)

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.get("https://api.elevenlabs.io/v1/history")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('GET', 'https://api.elevenlabs.io/v1/history');

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://api.elevenlabs.io/v1/history");
var request = new RestRequest(Method.GET);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let request = NSMutableURLRequest(url: NSURL(string: "https://api.elevenlabs.io/v1/history")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "GET"

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```

# Get history item

GET https://api.elevenlabs.io/v1/history/{history_item_id}

Retrieves a history item.

Reference: https://elevenlabs.io/docs/api-reference/history/get

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: api
  version: 1.0.0
paths:
  /v1/history/{history_item_id}:
    get:
      operationId: get
      summary: Get history item
      description: Retrieves a history item.
      tags:
        - subpackage_history
      parameters:
        - name: history_item_id
          in: path
          description: >-
            ID of the history item to be used. You can use the [Get generated
            items](/docs/api-reference/history/list) endpoint to retrieve a list
            of history items.
          required: true
          schema:
            type: string
        - name: xi-api-key
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/SpeechHistoryItemResponseModel'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
servers:
  - url: https://api.elevenlabs.io
  - url: https://api.us.elevenlabs.io
  - url: https://api.eu.residency.elevenlabs.io
  - url: https://api.in.residency.elevenlabs.io
components:
  schemas:
    SpeechHistoryItemResponseModelVoiceCategory:
      type: string
      enum:
        - premade
        - cloned
        - generated
        - professional
      description: >-
        The category of the voice. Either 'premade', 'cloned', 'generated' or
        'professional'.
      title: SpeechHistoryItemResponseModelVoiceCategory
    FeedbackResponseModel:
      type: object
      properties:
        thumbs_up:
          type: boolean
          description: Whether the user liked the generated item.
        feedback:
          type: string
          description: The feedback text provided by the user.
        emotions:
          type: boolean
          description: Whether the user provided emotions.
        inaccurate_clone:
          type: boolean
          description: Whether the user thinks the clone is inaccurate.
        glitches:
          type: boolean
          description: Whether the user thinks there are glitches in the audio.
        audio_quality:
          type: boolean
          description: Whether the user thinks the audio quality is good.
        other:
          type: boolean
          description: Whether the user provided other feedback.
        review_status:
          type: string
          default: not_reviewed
          description: The review status of the item. Defaults to 'not_reviewed'.
      required:
        - thumbs_up
        - feedback
        - emotions
        - inaccurate_clone
        - glitches
        - audio_quality
        - other
      title: FeedbackResponseModel
    SpeechHistoryItemResponseModelSource:
      type: string
      enum:
        - TTS
        - STS
        - Projects
        - PD
        - AN
        - Dubbing
        - PlayAPI
        - ConvAI
        - VoiceGeneration
        - InVPC
      description: >-
        The source of the history item. Either TTS (text to speech), STS (speech
        to text), AN (audio native), Projects, Dubbing, PlayAPI, PD
        (pronunciation dictionary) or ConvAI (Agents Platform).
      title: SpeechHistoryItemResponseModelSource
    HistoryAlignmentResponseModel:
      type: object
      properties:
        characters:
          type: array
          items:
            type: string
          description: The characters in the alignment.
        character_start_times_seconds:
          type: array
          items:
            type: number
            format: double
          description: The start times of the characters in seconds.
        character_end_times_seconds:
          type: array
          items:
            type: number
            format: double
          description: The end times of the characters in seconds.
      required:
        - characters
        - character_start_times_seconds
        - character_end_times_seconds
      title: HistoryAlignmentResponseModel
    HistoryAlignmentsResponseModel:
      type: object
      properties:
        alignment:
          $ref: '#/components/schemas/HistoryAlignmentResponseModel'
          description: The alignment of the text.
        normalized_alignment:
          $ref: '#/components/schemas/HistoryAlignmentResponseModel'
          description: The normalized alignment of the text.
      required:
        - alignment
        - normalized_alignment
      title: HistoryAlignmentsResponseModel
    DialogueInputResponseModel:
      type: object
      properties:
        text:
          type: string
          description: The text of the dialogue input line.
        voice_id:
          type: string
          description: The ID of the voice used for this dialogue input line.
        voice_name:
          type: string
          description: The name of the voice used for this dialogue input line.
      required:
        - text
        - voice_id
        - voice_name
      title: DialogueInputResponseModel
    SpeechHistoryItemResponseModel:
      type: object
      properties:
        history_item_id:
          type: string
          description: The ID of the history item.
        request_id:
          type:
            - string
            - 'null'
          description: The ID of the request.
        voice_id:
          type:
            - string
            - 'null'
          description: The ID of the voice used.
        model_id:
          type:
            - string
            - 'null'
          description: The ID of the model.
        voice_name:
          type:
            - string
            - 'null'
          description: The name of the voice.
        voice_category:
          oneOf:
            - $ref: '#/components/schemas/SpeechHistoryItemResponseModelVoiceCategory'
            - type: 'null'
          description: >-
            The category of the voice. Either 'premade', 'cloned', 'generated'
            or 'professional'.
        text:
          type:
            - string
            - 'null'
          description: The text used to generate the audio item.
        date_unix:
          type: integer
          description: Unix timestamp of when the item was created.
        character_count_change_from:
          type: integer
          description: The character count change from.
        character_count_change_to:
          type: integer
          description: The character count change to.
        content_type:
          type: string
          description: The content type of the generated item.
        state:
          description: Any type
        settings:
          type:
            - object
            - 'null'
          additionalProperties:
            description: Any type
          description: The settings of the history item.
        feedback:
          oneOf:
            - $ref: '#/components/schemas/FeedbackResponseModel'
            - type: 'null'
          description: >-
            Feedback associated with the generated item. Returns null if no
            feedback has been provided.
        share_link_id:
          type:
            - string
            - 'null'
          description: The ID of the share link.
        source:
          oneOf:
            - $ref: '#/components/schemas/SpeechHistoryItemResponseModelSource'
            - type: 'null'
          description: >-
            The source of the history item. Either TTS (text to speech), STS
            (speech to text), AN (audio native), Projects, Dubbing, PlayAPI, PD
            (pronunciation dictionary) or ConvAI (Agents Platform).
        alignments:
          oneOf:
            - $ref: '#/components/schemas/HistoryAlignmentsResponseModel'
            - type: 'null'
          description: The alignments of the history item.
        dialogue:
          type:
            - array
            - 'null'
          items:
            $ref: '#/components/schemas/DialogueInputResponseModel'
          description: >-
            The dialogue (voice and text pairs) used to generate the audio item.
            If this is set then the top level `text` and `voice_id` fields will
            be empty.
        output_format:
          type:
            - string
            - 'null'
          description: The output format the audio was originally generated in.
      required:
        - history_item_id
        - date_unix
        - character_count_change_from
        - character_count_change_to
        - content_type
        - state
      title: SpeechHistoryItemResponseModel
    ValidationErrorLocItems:
      oneOf:
        - type: string
        - type: integer
      title: ValidationErrorLocItems
    ValidationError:
      type: object
      properties:
        loc:
          type: array
          items:
            $ref: '#/components/schemas/ValidationErrorLocItems'
        msg:
          type: string
        type:
          type: string
      required:
        - loc
        - msg
        - type
      title: ValidationError
    HTTPValidationError:
      type: object
      properties:
        detail:
          type: array
          items:
            $ref: '#/components/schemas/ValidationError'
      title: HTTPValidationError

```

## SDK Code Examples

```typescript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";

async function main() {
    const client = new ElevenLabsClient();
    await client.history.get("history_item_id");
}
main();

```

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

client.history.get(
    history_item_id="history_item_id",
)

```

```go
package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {

	url := "https://api.elevenlabs.io/v1/history/history_item_id"

	req, _ := http.NewRequest("GET", url, nil)

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://api.elevenlabs.io/v1/history/history_item_id")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Get.new(url)

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.get("https://api.elevenlabs.io/v1/history/history_item_id")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('GET', 'https://api.elevenlabs.io/v1/history/history_item_id');

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://api.elevenlabs.io/v1/history/history_item_id");
var request = new RestRequest(Method.GET);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let request = NSMutableURLRequest(url: NSURL(string: "https://api.elevenlabs.io/v1/history/history_item_id")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "GET"

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```

# Delete history item

DELETE https://api.elevenlabs.io/v1/history/{history_item_id}

Delete a history item by its ID

Reference: https://elevenlabs.io/docs/api-reference/history/delete

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: api
  version: 1.0.0
paths:
  /v1/history/{history_item_id}:
    delete:
      operationId: delete
      summary: Delete history item
      description: Delete a history item by its ID
      tags:
        - subpackage_history
      parameters:
        - name: history_item_id
          in: path
          description: >-
            ID of the history item to be used. You can use the [Get generated
            items](/docs/api-reference/history/list) endpoint to retrieve a list
            of history items.
          required: true
          schema:
            type: string
        - name: xi-api-key
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeleteHistoryItemResponse'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
servers:
  - url: https://api.elevenlabs.io
  - url: https://api.us.elevenlabs.io
  - url: https://api.eu.residency.elevenlabs.io
  - url: https://api.in.residency.elevenlabs.io
components:
  schemas:
    DeleteHistoryItemResponse:
      type: object
      properties:
        status:
          type: string
          description: >-
            The status of the deletion request. If the request was successful,
            the status will be 'ok'. Otherwise an error message with http code
            500 will be returned.
      required:
        - status
      title: DeleteHistoryItemResponse
    ValidationErrorLocItems:
      oneOf:
        - type: string
        - type: integer
      title: ValidationErrorLocItems
    ValidationError:
      type: object
      properties:
        loc:
          type: array
          items:
            $ref: '#/components/schemas/ValidationErrorLocItems'
        msg:
          type: string
        type:
          type: string
      required:
        - loc
        - msg
        - type
      title: ValidationError
    HTTPValidationError:
      type: object
      properties:
        detail:
          type: array
          items:
            $ref: '#/components/schemas/ValidationError'
      title: HTTPValidationError

```

## SDK Code Examples

```typescript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";

async function main() {
    const client = new ElevenLabsClient();
    await client.history.delete("history_item_id");
}
main();

```

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

client.history.delete(
    history_item_id="history_item_id",
)

```

```go
package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {

	url := "https://api.elevenlabs.io/v1/history/history_item_id"

	req, _ := http.NewRequest("DELETE", url, nil)

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://api.elevenlabs.io/v1/history/history_item_id")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Delete.new(url)

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.delete("https://api.elevenlabs.io/v1/history/history_item_id")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('DELETE', 'https://api.elevenlabs.io/v1/history/history_item_id');

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://api.elevenlabs.io/v1/history/history_item_id");
var request = new RestRequest(Method.DELETE);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let request = NSMutableURLRequest(url: NSURL(string: "https://api.elevenlabs.io/v1/history/history_item_id")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "DELETE"

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```

# Get audio from history item

GET https://api.elevenlabs.io/v1/history/{history_item_id}/audio

Returns the audio of an history item.

Reference: https://elevenlabs.io/docs/api-reference/history/get-audio

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: api
  version: 1.0.0
paths:
  /v1/history/{history_item_id}/audio:
    get:
      operationId: get-audio
      summary: Get audio from history item
      description: Returns the audio of an history item.
      tags:
        - subpackage_history
      parameters:
        - name: history_item_id
          in: path
          description: >-
            ID of the history item to be used. You can use the [Get generated
            items](/docs/api-reference/history/list) endpoint to retrieve a list
            of history items.
          required: true
          schema:
            type: string
        - name: xi-api-key
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: The audio file of the history item.
          content:
            application/octet-stream:
              schema:
                type: string
                format: binary
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
servers:
  - url: https://api.elevenlabs.io
  - url: https://api.us.elevenlabs.io
  - url: https://api.eu.residency.elevenlabs.io
  - url: https://api.in.residency.elevenlabs.io
components:
  schemas:
    ValidationErrorLocItems:
      oneOf:
        - type: string
        - type: integer
      title: ValidationErrorLocItems
    ValidationError:
      type: object
      properties:
        loc:
          type: array
          items:
            $ref: '#/components/schemas/ValidationErrorLocItems'
        msg:
          type: string
        type:
          type: string
      required:
        - loc
        - msg
        - type
      title: ValidationError
    HTTPValidationError:
      type: object
      properties:
        detail:
          type: array
          items:
            $ref: '#/components/schemas/ValidationError'
      title: HTTPValidationError

```

## SDK Code Examples

```typescript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";

async function main() {
    const client = new ElevenLabsClient();
    await client.history.getAudio("history_item_id");
}
main();

```

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

client.history.get_audio(
    history_item_id="history_item_id",
)

```

```go
package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {

	url := "https://api.elevenlabs.io/v1/history/history_item_id/audio"

	req, _ := http.NewRequest("GET", url, nil)

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://api.elevenlabs.io/v1/history/history_item_id/audio")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Get.new(url)

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.get("https://api.elevenlabs.io/v1/history/history_item_id/audio")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('GET', 'https://api.elevenlabs.io/v1/history/history_item_id/audio');

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://api.elevenlabs.io/v1/history/history_item_id/audio");
var request = new RestRequest(Method.GET);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let request = NSMutableURLRequest(url: NSURL(string: "https://api.elevenlabs.io/v1/history/history_item_id/audio")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "GET"

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```

# Download history items

POST https://api.elevenlabs.io/v1/history/download
Content-Type: application/json

Download one or more history items. If one history item ID is provided, we will return a single audio file. If more than one history item IDs are provided, we will provide the history items packed into a .zip file.

Reference: https://elevenlabs.io/docs/api-reference/history/download

## OpenAPI Specification

```yaml
openapi: 3.1.0
info:
  title: api
  version: 1.0.0
paths:
  /v1/history/download:
    post:
      operationId: download
      summary: Download history items
      description: >-
        Download one or more history items. If one history item ID is provided,
        we will return a single audio file. If more than one history item IDs
        are provided, we will provide the history items packed into a .zip file.
      tags:
        - subpackage_history
      parameters:
        - name: xi-api-key
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: >-
            The requested audio file, or a zip file containing multiple audio
            files when multiple history items are requested.
          content:
            application/octet-stream:
              schema:
                type: string
                format: binary
        '400':
          description: Invalid request
          content:
            application/json:
              schema:
                $ref: >-
                  #/components/schemas/Download_speech_history_itemsRequestBadRequestError
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
      requestBody:
        content:
          application/json:
            schema:
              $ref: >-
                #/components/schemas/Body_Download_history_items_v1_history_download_post
servers:
  - url: https://api.elevenlabs.io
  - url: https://api.us.elevenlabs.io
  - url: https://api.eu.residency.elevenlabs.io
  - url: https://api.in.residency.elevenlabs.io
components:
  schemas:
    Body_Download_history_items_v1_history_download_post:
      type: object
      properties:
        history_item_ids:
          type: array
          items:
            type: string
          description: >-
            A list of history items to download, you can get IDs of history
            items and other metadata using the GET
            https://api.elevenlabs.io/v1/history endpoint.
        output_format:
          type:
            - string
            - 'null'
          description: Output format to transcode the audio file, can be wav or default.
      required:
        - history_item_ids
      title: Body_Download_history_items_v1_history_download_post
    Download_speech_history_itemsRequestBadRequestError:
      type: object
      properties:
        error:
          type: string
        message:
          type: string
      title: Download_speech_history_itemsRequestBadRequestError
    ValidationErrorLocItems:
      oneOf:
        - type: string
        - type: integer
      title: ValidationErrorLocItems
    ValidationError:
      type: object
      properties:
        loc:
          type: array
          items:
            $ref: '#/components/schemas/ValidationErrorLocItems'
        msg:
          type: string
        type:
          type: string
      required:
        - loc
        - msg
        - type
      title: ValidationError
    HTTPValidationError:
      type: object
      properties:
        detail:
          type: array
          items:
            $ref: '#/components/schemas/ValidationError'
      title: HTTPValidationError

```

## SDK Code Examples

```typescript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";

async function main() {
    const client = new ElevenLabsClient();
    await client.history.download({
        historyItemIds: [
            "string",
        ],
    });
}
main();

```

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

client.history.download(
    history_item_ids=[
        "string"
    ],
)

```

```go
package main

import (
	"fmt"
	"strings"
	"net/http"
	"io"
)

func main() {

	url := "https://api.elevenlabs.io/v1/history/download"

	payload := strings.NewReader("{\n  \"history_item_ids\": [\n    \"string\"\n  ]\n}")

	req, _ := http.NewRequest("POST", url, payload)

	req.Header.Add("Content-Type", "application/json")

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := io.ReadAll(res.Body)

	fmt.Println(res)
	fmt.Println(string(body))

}
```

```ruby
require 'uri'
require 'net/http'

url = URI("https://api.elevenlabs.io/v1/history/download")

http = Net::HTTP.new(url.host, url.port)
http.use_ssl = true

request = Net::HTTP::Post.new(url)
request["Content-Type"] = 'application/json'
request.body = "{\n  \"history_item_ids\": [\n    \"string\"\n  ]\n}"

response = http.request(request)
puts response.read_body
```

```java
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

HttpResponse<String> response = Unirest.post("https://api.elevenlabs.io/v1/history/download")
  .header("Content-Type", "application/json")
  .body("{\n  \"history_item_ids\": [\n    \"string\"\n  ]\n}")
  .asString();
```

```php
<?php
require_once('vendor/autoload.php');

$client = new \GuzzleHttp\Client();

$response = $client->request('POST', 'https://api.elevenlabs.io/v1/history/download', [
  'body' => '{
  "history_item_ids": [
    "string"
  ]
}',
  'headers' => [
    'Content-Type' => 'application/json',
  ],
]);

echo $response->getBody();
```

```csharp
using RestSharp;

var client = new RestClient("https://api.elevenlabs.io/v1/history/download");
var request = new RestRequest(Method.POST);
request.AddHeader("Content-Type", "application/json");
request.AddParameter("application/json", "{\n  \"history_item_ids\": [\n    \"string\"\n  ]\n}", ParameterType.RequestBody);
IRestResponse response = client.Execute(request);
```

```swift
import Foundation

let headers = ["Content-Type": "application/json"]
let parameters = ["history_item_ids": ["string"]] as [String : Any]

let postData = JSONSerialization.data(withJSONObject: parameters, options: [])

let request = NSMutableURLRequest(url: NSURL(string: "https://api.elevenlabs.io/v1/history/download")! as URL,
                                        cachePolicy: .useProtocolCachePolicy,
                                    timeoutInterval: 10.0)
request.httpMethod = "POST"
request.allHTTPHeaderFields = headers
request.httpBody = postData as Data

let session = URLSession.shared
let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
  if (error != nil) {
    print(error as Any)
  } else {
    let httpResponse = response as? HTTPURLResponse
    print(httpResponse)
  }
})

dataTask.resume()
```
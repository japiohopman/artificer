De World Context Button moet zich dynamisch aanpassen aan het type content waarvoor hij wordt gebruikt. Een SFX-context vereist andere instellingen, parameters en prompts dan bijvoorbeeld een Weather-context. De configuratie mag daarom niet statisch zijn, maar context-afhankelijk worden opgebouwd.

Daarnaast moet het System de UI-structuur kunnen mappen. Voor de UI-context is waarschijnlijk ook een specifiekere en beter geoptimaliseerde prompt voor Gemini nodig, zodat de gegenereerde output beter aansluit op interface-elementen en gebruikersinteracties.

Ik ga hiervoor aanpassingen doorvoeren in de repository.

Actiepunten
World Context Button dynamisch maken
Context-specifieke configuraties ondersteunen (bijv. SFX, Weather, UI, System).
Per context eigen prompt-, model- en parameterinstellingen gebruiken.
Configuraties uitbreidbaar maken voor toekomstige contexttypen.
System ↔ UI Mapping
Een duidelijke mappinglaag introduceren tussen systeemcomponenten en UI-elementen.
UI-gerelateerde prompts los beheren van generieke systeem-prompts.
sound_manager.txt aanpassen
Updaten naar de datastructuur die we momenteel binnen het project gebruiken.
Ondersteuning toevoegen voor hiërarchische categorieën en assets.
Submappenstructuur voor audio
Voorstel:public/assets/sounds
sound/
├── system/
│   ├── ui/
│   └── notifications/
├── voice/
│   ├── npc/male1
│   ├── narrater/
├── weather/
│   ├── rain/
│   ├── thunder/
│   └── wind/ ect
└── ambience/
    └── tavern/
        └── night/
└── sfx/
    └── spell/
   en wat we al hebben dan zet ik dit in de juiste map  
Deze structuur maakt beheer, caching en toekomstige uitbreidingen eenvoudiger.

Audioformaat

Voor realtime UI-geluiden wordt vaak OGG Vorbis gebruikt vanwege:

lage bestandsgrootte;
goede audiokwaliteit;
snelle laadtijden;
brede ondersteuning in game-engines en applicaties.
Vraag: Kan ElevenLabs OGG leveren?

Voor zover bekend levert ElevenLabs primair audio in formaten zoals MP3 en WAV. Wanneer OGG nodig is, kun je de gegenereerde bestanden automatisch converteren tijdens de build- of asset-pipeline.

Voorbeeld workflow:

ElevenLabs → WAV (master)
           ↓
      OGG Vorbis (runtime)

Dit heeft als voordeel dat:

WAV als kwaliteitsbron behouden blijft;
OGG automatisch kan worden geoptimaliseerd voor distributie;
toekomstige formaten eenvoudig kunnen worden toegevoegd.
Aanbeveling

Gebruik WAV als bronbestand en genereer tijdens de asset-pipeline automatisch OGG-bestanden voor runtime-gebruik. Dat geeft de meeste flexibiliteit en voorkomt kwaliteitsverlies door meerdere conversiestappen. Bovendien sluit dit goed aan bij een gestructureerde audioarchitectuur met context-specifieke mappen zoals system/ui/button_click.
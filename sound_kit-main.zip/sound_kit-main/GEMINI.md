# Arcane Ambiance: Project Guidelines

## Overview
This project is a tool within the **Artificer Reality Engine**. It focuses on orchestrating environmental "Ambiance" by synchronizing audio and lighting.

## Core Agent: Sonny
**Sonny** is the Atmospheric Orchestrator. 
- **Domain:** Audio (SFX, Voice, Ambient, Weather, Music) and Lighting (Philips Hue).
- **Tools:** ElevenLabs (Audio), Gemini (Atmospheric Translation), GitHub Octokit (Registry Management).
- **Expanded Role:** See `docs/SONNY_PROSPECTUS.md` for the full definition of Sonny's capabilities as a Technical Audio Lead and Atmospheric Architect.

## Project Structure
- `bridge/`: Contains instructions and workflows for agent collaboration.
- `src/components/`: UI components for the "Sound Studio", "Arcane Forge", and "Communication Bridge".
- `src/hueStore.ts`: Zustand store for managing Philips Hue connectivity and "Spores" (lighting animations).
- `server.ts`: Backend proxy for GitHub, ElevenLabs, Gemini, and Hue Cloud.

## Conventions
- **Asset Management:** All audio assets must be registered in the `AUDIO_REGISTRY.md` (on the CDN repo).
- **Commissioning:** Use the `AUDIO_REQUESTS.md` for agent-to-agent asset requests.
- **Tone:** Professional, technical, and immersive. Use "Sonny" as the persona for audio-visual orchestration tasks.

## Technical Details
- **Frontend:** React + Vite + Tailwind CSS + Lucide Icons.
- **Audio Engine:** Howler.js.
- **Lighting:** Philips Hue API (v2).
- **State:** Zustand.
- **Backend:** Express + Node.js + Multer (for asset uploads).

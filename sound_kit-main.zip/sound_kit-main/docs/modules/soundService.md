# Sound Service Module

## Purpose
The `SoundEngine` manages the atmospheric soundscape of Artificer. It provides a robust, multi-layered audio mixing system designed for high-fidelity environmental immersion and reactive game events.

## Professional Owner
**Sunny** (Professional Audio Generator & Editor)

## Architecture
The system is built on **Howler.js** and integrated into the React/Zustand lifecycle.

### 1. Multi-Layered Mixing
Audio is categorized into five distinct layers to allow for independent volume control and state management:
- **Ambient**: Environmental background loops (e.g., Tavern chatter, forest wind).
- **Weather**: Reactive weather effects (e.g., Rain, Thunder).
- **EFX**: Instant sound effects for spells, actions, or UI events.
- **Voice**: Character dialogue and vocalizations.
- **Music**: Thematic background scores.

### 2. Core Components
- `AudioEngine.ts`: The central controller managing `SoundInstance` lifecycles and global volume calculations.
- `LayerManager.ts`: Handles the logical state (volume, mute, solo) for each audio layer.
- `AudioRegistry.md`: The professional inventory of all project assets.
- `AudioRequestMap.md`: The agent-to-agent communication bridge for asset commissioning.

## Professional Pipeline (The Sunny Workflow)
1. **Commissioning**: Requirements are posted to the **Request Map** (`AUDIO_REQUESTS.md`).
2. **Analysis**: Sunny (the Audio Agent) analyzes the request and provides technical generation prompts.
3. **Generation**: Assets are forged via the **Audio Studio** (ElevenLabs integration).
4. **Baking**: Validated assets are uploaded to the repository via the `update_repository` protocol.
5. **Registry**: Sunny updates the **Audio Registry** (`AUDIO_REGISTRY.md`) once the asset is live.

## Asset Storage Map
- `public/assets/sounds/ambient/`: Continuous loops.
- `public/assets/sounds/sfx/`: Discrete effects.
- `public/assets/sounds/npc_voice/`: Dialogue.
- `public/assets/sounds/weather/`: Environmental layers.

## Technical API
- `playSound(id)`: Triggers an asset by ID from the `SOUND_MANIFEST`.
- `stopAll(layer?)`: Stops all playback or filters by a specific layer.
- `updateVolumes()`: Synchronizes all active instances with the `LayerManager` state.

## Current Limitations & Future Work
- **Autoplay**: Browser policies require user interaction before the first sound can play.
- **Cross-fading**: Dynamic transitions between ambient layers are planned.
- **Spatial Audio**: 3D panning for directional SFX is under research.

import { useEffect, useRef, useState, useCallback } from 'react';
import { AudioEngine } from '../engine/audioEngine';
import { LayerManager } from '../engine/layerManager';
import type { AudioLayer, LayerState, SoundIndex } from '../types/audio';

export function useAudioEngine() {
  const layerManagerRef = useRef(new LayerManager());
  const audioEngineRef = useRef(new AudioEngine(layerManagerRef.current));
  
  const [layerStates, setLayerStates] = useState<Record<AudioLayer, LayerState>>(() => {
    const states: any = {};
    const layers: AudioLayer[] = ['ambient', 'weather', 'efx', 'voice', 'music'];
    layers.forEach(l => {
        states[l] = layerManagerRef.current.getLayerState(l);
    });
    return states;
  });

  const [masterVolume, setMasterVolume] = useState(1.0);
  const [soundIndex, setSoundIndex] = useState<SoundIndex | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchIndex = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/audio/index");
      const data = await res.json();
      setSoundIndex(data);
    } catch (error) {
      console.error('Failed to fetch sound index:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchIndex();
  }, [fetchIndex]);

  const updateLayerVolume = (layer: AudioLayer, volume: number) => {
    layerManagerRef.current.setVolume(layer, volume);
    setLayerStates(prev => ({
      ...prev,
      [layer]: layerManagerRef.current.getLayerState(layer)
    }));
    audioEngineRef.current.updateVolumes();
  };

  const updateMasterVolume = (volume: number) => {
    layerManagerRef.current.setMasterVolume(volume);
    setMasterVolume(volume);
    audioEngineRef.current.updateVolumes();
  };

  const toggleMute = (layer: AudioLayer) => {
    const currentState = layerManagerRef.current.getLayerState(layer);
    layerManagerRef.current.setMute(layer, !currentState.muted);
    setLayerStates(prev => ({
      ...prev,
      [layer]: layerManagerRef.current.getLayerState(layer)
    }));
    audioEngineRef.current.updateVolumes();
  };

  const toggleSolo = (layer: AudioLayer) => {
    const currentState = layerManagerRef.current.getLayerState(layer);
    layerManagerRef.current.setSolo(layer, !currentState.solo);
    
    const layers: AudioLayer[] = ['ambient', 'weather', 'efx', 'voice', 'music'];
    const newStates: any = {};
    layers.forEach(l => {
        newStates[l] = layerManagerRef.current.getLayerState(l);
    });
    setLayerStates(newStates);
    audioEngineRef.current.updateVolumes();
  };

  const playSound = (id: string) => {
    if (!soundIndex?.sounds[id]) return;
    return audioEngineRef.current.play(soundIndex.sounds[id]);
  };

  const stopAll = (layer?: AudioLayer) => {
    audioEngineRef.current.stopAll(layer);
  };

  return {
    layerStates,
    masterVolume,
    soundIndex,
    loading,
    updateLayerVolume,
    updateMasterVolume,
    toggleMute,
    toggleSolo,
    playSound,
    stopAll,
    refreshIndex: fetchIndex
  };
}

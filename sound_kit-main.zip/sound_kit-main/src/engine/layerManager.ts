import { AudioLayer, LayerState } from '../types/audio';

export class LayerManager {
  private states: Record<AudioLayer, LayerState>;
  private masterVolume: number = 1.0;

  constructor() {
    this.states = {
      ambient: { volume: 0.8, muted: false, solo: false },
      weather: { volume: 0.8, muted: false, solo: false },
      efx: { volume: 1.0, muted: false, solo: false },
      voice: { volume: 1.0, muted: false, solo: false },
      music: { volume: 0.7, muted: false, solo: false }
    };
  }

  setVolume(layer: AudioLayer, volume: number) {
    this.states[layer].volume = Math.max(0, Math.min(1, volume));
  }

  setMasterVolume(volume: number) {
    this.masterVolume = Math.max(0, Math.min(1, volume));
  }

  setMute(layer: AudioLayer, muted: boolean) {
    this.states[layer].muted = muted;
  }

  setSolo(layer: AudioLayer, solo: boolean) {
    this.states[layer].solo = solo;
  }

  getEffectiveVolume(layer: AudioLayer): number {
    const state = this.states[layer];
    if (state.muted) return 0;

    // If any layer is soloed, and this one isn't, return 0
    const anySolo = Object.values(this.states).some(s => s.solo);
    if (anySolo && !state.solo) return 0;

    return state.volume * this.masterVolume;
  }

  getLayerState(layer: AudioLayer): LayerState {
    return { ...this.states[layer] };
  }

  getMasterVolume(): number {
    return this.masterVolume;
  }
}

import { Howl } from 'howler';
import { LayerManager } from './layerManager';
import type { SoundMetadata, AudioLayer } from '../types/audio';

const BASE_URL = 'https://cdn.jsdelivr.net/gh/japiohopman/artificer@main/public/';

export interface PlaybackOptions {
  volume?: number;
  pitch?: number;
  loop?: boolean;
}

export class SoundInstance {
  private howl: Howl;
  private metadata: SoundMetadata;
  private layer: AudioLayer;
  private instanceId: number | null = null;

  constructor(metadata: SoundMetadata, options: PlaybackOptions = {}) {
    this.metadata = metadata;
    this.layer = metadata.type;
    this.howl = new Howl({
      src: [`${BASE_URL}${metadata.file}`],
      volume: (options.volume ?? metadata.volume) || 1,
      rate: options.pitch ?? 1.0,
      loop: options.loop ?? metadata.loop,
      html5: true, // For larger files
    });
  }

  play() {
    this.instanceId = this.howl.play();
  }

  pause() {
    this.howl.pause();
  }

  resume() {
    this.howl.play();
  }

  stop() {
    this.howl.stop();
  }

  isPlaying() {
    return this.howl.playing();
  }

  setVolume(volume: number) {
    if (this.instanceId !== null) {
      this.howl.volume(volume, this.instanceId);
    } else {
      this.howl.volume(volume);
    }
  }

  getLayer() {
    return this.layer;
  }

  getMetadata() {
    return this.metadata;
  }
}

export class AudioEngine {
  private activeInstances: Set<SoundInstance> = new Set();
  private layerManager: LayerManager;

  constructor(layerManager: LayerManager) {
    this.layerManager = layerManager;
  }

  play(metadata: SoundMetadata, options: PlaybackOptions = {}): SoundInstance {
    const instance = new SoundInstance(metadata, options);
    this.activeInstances.add(instance);

    const effectiveVolume = this.calculateEffectiveVolume(instance);
    instance.setVolume(effectiveVolume);

    instance.play();
    return instance;
  }

  private calculateEffectiveVolume(instance: SoundInstance): number {
    const meta = instance.getMetadata();
    const layerVolume = this.layerManager.getEffectiveVolume(meta.type);
    return (meta.volume || 1) * layerVolume;
  }

  updateVolumes() {
    for (const instance of this.activeInstances) {
      const volume = this.calculateEffectiveVolume(instance);
      instance.setVolume(volume);
    }
  }

  stopAll(layer?: AudioLayer) {
    for (const instance of this.activeInstances) {
      if (layer === undefined || instance.getLayer() === layer) {
        instance.stop();
        this.activeInstances.delete(instance);
      }
    }
  }
}

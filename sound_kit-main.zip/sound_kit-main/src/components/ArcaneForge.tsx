
import { Wand2, Mic, Music, Loader2, Sparkles, Volume2 } from "lucide-react";
import { useState } from "react";
import { motion } from "motion/react";

interface ArcaneForgeProps {
    suggestions: {
        sfx_prompt: string;
        voice_prompt: string;
        category: string;
    } | null;
    voiceOptions: { id: string; label: string }[];
    selectedVoiceId: string;
    onSelectVoice: (voiceId: string) => void;
    onGenerateSFX: (prompt: string) => Promise<void>;
    onGenerateVoice: (text: string) => Promise<void>;
}

export function ArcaneForge({ suggestions, voiceOptions, selectedVoiceId, onSelectVoice, onGenerateSFX, onGenerateVoice }: ArcaneForgeProps) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [customPrompt, setCustomPrompt] = useState("");

    const handleSFX = async () => {
        setIsGenerating(true);
        try {
            await onGenerateSFX(customPrompt || suggestions?.sfx_prompt || "");
        } finally {
            setIsGenerating(false);
        }
    };

    if (!suggestions && !customPrompt) return null;

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-700">
            <div className="flex items-center gap-2">
                <Wand2 className="w-3.5 h-3.5 text-stone-500" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-stone-400">Sound Generator</span>
            </div>

            <div className="p-6 rounded-2xl bg-stone-950/20 border border-stone-800/40 space-y-4 shadow-inner">
                {suggestions && (
                    <div className="space-y-3">
                        <div className="flex items-start gap-3">
                            <Music className="w-3.5 h-3.5 text-stone-600 mt-0.5" />
                            <div className="space-y-1">
                                <p className="text-[10px] uppercase tracking-tighter text-stone-600 font-bold">Suggested Prompt</p>
                                <p className="text-[12px] text-stone-400 italic font-sans leading-relaxed">"{suggestions.sfx_prompt}"</p>
                            </div>
                        </div>
                    </div>
                )}

                {voiceOptions.length > 0 && (
                    <div className="space-y-4">
                        <div className="flex items-center justify-between gap-3">
                            <div>
                                <p className="text-[10px] uppercase tracking-tighter text-stone-600 font-bold">NPC Voice Model</p>
                                <p className="text-[11px] text-stone-400 italic font-sans">Choose one of your configured ElevenLabs voices.</p>
                            </div>
                            <select
                                id="voice-model-select"
                                value={selectedVoiceId}
                                onChange={(e) => onSelectVoice(e.target.value)}
                                aria-label="NPC voice model"
                                className="bg-stone-950 border border-stone-800 rounded-xl p-3 text-[12px] font-sans focus:outline-none focus:border-stone-600 text-stone-300"
                            >
                                {voiceOptions.map((voice) => (
                                    <option key={voice.label} value={voice.id}>
                                        {voice.label}{voice.id ? ` (${voice.id.slice(0, 6)}...)` : " — unconfigured"}
                                    </option>
                                ))}
                            </select>
                        </div>
                    </div>
                )}

                <div className="flex gap-2 flex-col sm:flex-row">
                    <button
                        onClick={handleSFX}
                        disabled={isGenerating}
                        className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 text-[10px] font-bold uppercase tracking-widest hover:bg-stone-700 transition-all disabled:opacity-50 shadow-lg"
                    >
                        {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                        Generate Audio
                    </button>
                    <button
                        onClick={async () => {
                            setIsGenerating(true);
                            try {
                                await onGenerateVoice(customPrompt || suggestions?.voice_prompt || "");
                            } finally {
                                setIsGenerating(false);
                            }
                        }}
                        disabled={isGenerating || !selectedVoiceId}
                        className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-stone-700 text-stone-200 border border-stone-600 text-[10px] font-bold uppercase tracking-widest hover:bg-stone-600 transition-all disabled:opacity-50 shadow-lg"
                    >
                        {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Mic className="w-3.5 h-3.5" />}
                        Generate Voice
                    </button>
                </div>
            </div>
        </div>
    );
}


import { ENVIRONMENTS, SPELLS } from "./data";

export interface ToolDefinition {
    name: string;
    description: string;
    parameters: any;
}

export const HUE_TOOLS: ToolDefinition[] = [
    {
        name: "set_ambience",
        description: "Set the global lighting atmosphere based on a D&D environment.",
        parameters: {
            type: "object",
            properties: {
                environment_id: {
                    type: "string",
                    enum: ENVIRONMENTS.map(e => e.id),
                    description: "The ID of the environment to trigger."
                }
            },
            required: ["environment_id"]
        }
    },
    {
        name: "cast_spell",
        description: "Trigger a brief lighting effect representing a magic spell.",
        parameters: {
            type: "object",
            properties: {
                spell_id: {
                    type: "string",
                    enum: SPELLS.map(s => s.id),
                    description: "The ID of the spell to cast."
                },
                target_light_id: {
                    type: "string",
                    description: "Optional: The ID of a specific light to target. If omitted, all lights are affected."
                }
            },
            required: ["spell_id"]
        }
    },
    {
        name: "adjust_light",
        description: "Manually adjust a specific light's properties.",
        parameters: {
            type: "object",
            properties: {
                light_id: {
                    type: "string",
                    description: "The ID of the light to adjust."
                },
                brightness: {
                    type: "number",
                    description: "Brightness level (0-100)."
                },
                color_temp: {
                    type: "number",
                    description: "Color temperature in mireds (153-500)."
                },
                on: {
                    type: "boolean",
                    description: "Whether the light should be on or off."
                }
            },
            required: ["light_id"]
        }
    }
];

export function getHueSettingsForTool(name: string, args: any) {
    if (name === "set_ambience") {
        const env = ENVIRONMENTS.find(e => e.id === args.environment_id);
        return env ? env.hueSettings : null;
    }
    if (name === "cast_spell") {
        const spell = SPELLS.find(s => s.id === args.spell_id);
        return spell ? spell.hueSettings : null;
    }
    if (name === "adjust_light") {
        const settings: any = {};
        if (args.brightness !== undefined) settings.dimming = { brightness: args.brightness };
        if (args.color_temp !== undefined) settings.color_temperature = { mirek: args.color_temp };
        if (args.on !== undefined) settings.on = { on: args.on };
        return settings;
    }
    return null;
}

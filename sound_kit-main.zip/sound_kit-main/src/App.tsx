import React, { useState, useEffect } from 'react';
import { useAudioEngine } from './hooks/useAudioEngine';
import { useHueStore } from './hueStore';
import { SoundStudio } from './components/SoundStudio';
import { Soundscape } from './components/Soundscape';
import { ENVIRONMENTS } from './data';
import { Environment } from './types';
import { Wand2, Activity, Volume2, LayoutDashboard, Sun, Moon, Link as LinkIcon, RefreshCw } from 'lucide-react';

export default function App() {
  const {
    layerStates,
    masterVolume,
    soundIndex,
    loading,
    updateLayerVolume,
    updateMasterVolume,
    toggleMute,
    playSound,
    refreshIndex
  } = useAudioEngine();

  const hueStore = useHueStore();
  const [activeEnvironment, setActiveEnvironment] = useState<Environment | null>(ENVIRONMENTS[0]);
  const [selectedVoiceId, setSelectedVoiceId] = useState("");
  const [voiceOptions, setVoiceOptions] = useState([]);
  const [isLightMode, setIsLightMode] = useState(false);
  const [isSoundscapeCollapsed, setIsSoundscapeCollapsed] = useState(false);

  // Toggle theme
  useEffect(() => {
    if (isLightMode) {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [isLightMode]);

  // Hue Polling
  useEffect(() => {
    if (hueStore.isConnected) {
      const interval = setInterval(() => {
        hueStore.fetchUpdates();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [hueStore.isConnected]);

  // Mock voice options
  useEffect(() => {
    setVoiceOptions([
      { id: "21m00Tcm4TlvDq8ikWAM", label: "Rachel", accountIndex: 0 },
      { id: "AZnzlk1XvdvUeBnXmlld", label: "Domi", accountIndex: 0 },
      { id: "EXAVITQu4vr4xnSDxMaL", label: "Bella", accountIndex: 0 }
    ]);
  }, []);

  const handleGenerateVoice = async (text: string) => {
    try {
      const response = await fetch('/api/audio/generate-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voiceId: selectedVoiceId,
          settings: { stability: 0.5, similarity_boost: 0.5 },
          accountIndex: 0
        })
      });

      if (!response.ok) throw new Error('Failed to generate voice');

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();

      console.log("Voice generated and playing");
    } catch (error) {
      console.error("Voice generation failed:", error);
    }
  };

  const handleGenerateAudio = async (data: any) => {
    try {
      const response = await fetch('/api/audio/generate-sfx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: data.prompt,
          duration_seconds: data.duration,
          loop: data.isLoop,
          accountIndex: data.accountIndex || 0
        })
      });

      if (!response.ok) throw new Error('Failed to generate audio');

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      
      // Auto-upload the generated sound to the repo via the server
      const formData = new FormData();
      formData.append('file', blob, `${data.filename || 'generated'}.wav`);
      formData.append('id', data.filename || `gen_${Date.now()}`);
      formData.append('metadata', JSON.stringify({
        category: data.category || 'sfx',
        loop: data.isLoop,
        meta: { prompt: data.prompt }
      }));

      const uploadRes = await fetch('/api/audio/upload', {
        method: 'POST',
        body: formData
      });

      if (uploadRes.ok) {
        console.log("Audio generated and uploaded successfully");
        refreshIndex();
      }

      const audio = new Audio(url);
      audio.play();
    } catch (error) {
      console.error("Audio generation failed:", error);
    }
  };

  return (
    <div className="flex h-screen bg-stone-950 text-stone-200 overflow-hidden font-sans select-none transition-colors duration-300">
      {/* Sidebar: Audio & System Control */}
      <aside className={`flex-shrink-0 border-r border-stone-800 bg-stone-900/20 flex flex-col transition-all duration-300 ${isSoundscapeCollapsed ? 'w-20' : 'w-80'}`}>
        <div className="p-6 border-b border-stone-800 flex items-center justify-between">
          <div className={`flex items-center gap-3 transition-opacity duration-300 ${isSoundscapeCollapsed ? 'opacity-0 w-0' : 'opacity-100'}`}>
            <div className="p-2 bg-dragon-red/10 rounded-lg border border-dragon-red/20">
              <Activity className="w-5 h-5 text-dragon-red" />
            </div>
            <div>
              <h1 className="text-sm font-bold uppercase tracking-widest text-stone-200">Arcane Ambiance</h1>
              <p className="text-[10px] text-stone-500 uppercase font-bold tracking-tighter">Atmospheric Orchestrator</p>
            </div>
          </div>
          <button 
            onClick={() => setIsSoundscapeCollapsed(!isSoundscapeCollapsed)}
            className="p-2 rounded-lg bg-stone-800/50 border border-stone-700 text-stone-400 hover:text-stone-200 transition-all"
            title={isSoundscapeCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isSoundscapeCollapsed ? <RefreshCw className="w-4 h-4" /> : <RefreshCw className="w-4 h-4 rotate-180" />}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
          {!isSoundscapeCollapsed && (
            <>
              <section>
                <Soundscape 
                  masterVolume={masterVolume}
                  layerStates={layerStates}
                  onMasterVolumeChange={updateMasterVolume}
                  onLayerVolumeChange={updateLayerVolume}
                  onToggleMute={toggleMute}
                  onPanic={() => console.log("Panic!")}
                />
              </section>

              <section className="pt-8 border-t border-stone-800/50">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <LayoutDashboard className="w-3.5 h-3.5 text-stone-500" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-stone-400">Environment</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {ENVIRONMENTS.map(env => (
                    <button
                      key={env.id}
                      onClick={() => setActiveEnvironment(env)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        activeEnvironment?.id === env.id 
                          ? 'border-dragon-gold bg-dragon-gold/5 text-stone-200' 
                          : 'border-stone-800 bg-stone-900/20 text-stone-500 hover:border-stone-700'
                      }`}
                    >
                      <p className="text-[11px] font-bold uppercase tracking-wider">{env.name}</p>
                    </button>
                  ))}
                </div>
              </section>
            </>
          )}
          {isSoundscapeCollapsed && (
            <div className="flex flex-col items-center gap-6">
              <div className="p-2 bg-dragon-red/10 rounded-lg border border-dragon-red/20">
                <Activity className="w-5 h-5 text-dragon-red" />
              </div>
              <div className="h-px w-8 bg-stone-800" />
              <button className="p-2 text-stone-600 hover:text-stone-400">
                <Volume2 className="w-5 h-5" />
              </button>
              <button className="p-2 text-stone-600 hover:text-stone-400">
                <LayoutDashboard className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        <div className={`p-6 border-t border-stone-800 bg-stone-900/40 space-y-4 ${isSoundscapeCollapsed ? 'items-center flex flex-col' : ''}`}>
          <div className={`flex items-center justify-between w-full ${isSoundscapeCollapsed ? 'justify-center' : ''}`}>
            <div className={`flex items-center gap-2 ${isSoundscapeCollapsed ? 'hidden' : ''}`}>
              <LinkIcon className="w-3.5 h-3.5 text-stone-500" />
              <span className="text-[10px] font-bold text-stone-600 uppercase tracking-widest">Hue Bridge</span>
            </div>
            <div className="flex items-center gap-2">
                {hueStore.isConnected && (
                    <button 
                        onClick={() => hueStore.fetchUpdates()}
                        className="p-1 text-stone-600 hover:text-stone-400 transition-colors"
                    >
                        <RefreshCw className="w-3 h-3" />
                    </button>
                )}
                <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${hueStore.isConnected ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                    {hueStore.isConnected ? (isSoundscapeCollapsed ? 'ON' : 'Connected') : (isSoundscapeCollapsed ? 'OFF' : 'Offline')}
                </span>
            </div>
          </div>
          {!hueStore.isConnected && !isSoundscapeCollapsed && (
              <button 
                onClick={() => hueStore.connect()}
                className="w-full py-2 rounded-lg bg-stone-800 text-stone-300 border border-stone-700 text-[10px] font-bold uppercase tracking-widest hover:bg-stone-700 transition-all"
              >
                  Establish Connection
              </button>
          )}
        </div>
      </aside>

      {/* Main Content: Sound Studio */}
      <main className="flex-1 min-w-0 flex flex-col">
        <SoundStudio 
          activeEnvironment={activeEnvironment}
          voiceOptions={voiceOptions}
          selectedVoiceId={selectedVoiceId}
          isLightMode={isLightMode}
          onToggleTheme={() => setIsLightMode(!isLightMode)}
          onSelectVoice={setSelectedVoiceId}
          onGenerateVoice={handleGenerateVoice}
          onGenerateAudio={handleGenerateAudio}
        />
      </main>
    </div>
  );
}


import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import cookieSession from "cookie-session";
import qs from "qs";
import { GoogleGenAI } from "@google/genai";
import axios from "axios";
import https from "https";
import { Octokit } from "octokit";
import multer from "multer";
import fs from "fs/promises";
import { getHueSettingsForTool } from "./src/tools";

dotenv.config();

const upload = multer();

const octokit = new Octokit({
  auth: process.env.GITHUB_PAT
});

const ELEVENLABS_KEYS = [
  sanitizeEnvValue(process.env.ELEVENLABS_KEY_1),
  sanitizeEnvValue(process.env.ELEVENLABS_KEY_2),
  sanitizeEnvValue(process.env.ELEVENLABS_KEY_3)
];

console.log(`ElevenLabs Keys Configured: ${ELEVENLABS_KEYS.filter(k => k.length > 0).length} accounts active.`);

function getElevenLabsKey(accountIndex: number = 0) {
  const key = ELEVENLABS_KEYS[accountIndex];
  
  if (key) {
    const masked = `${key.slice(0, 4)}...${key.slice(-4)}`;
    console.log(`Using ElevenLabs Key for Account ${accountIndex + 1}: ${masked} (len: ${key.length})`);
  }

  if (!key || key.length < 10) {
    const fallbackIdx = ELEVENLABS_KEYS.findIndex(k => k && k.length > 10);
    const fallback = fallbackIdx !== -1 ? ELEVENLABS_KEYS[fallbackIdx] : "";
    console.warn(`Invalid or missing ElevenLabs key for account index ${accountIndex}. Falling back to account ${fallbackIdx + 1}.`);
    return fallback || "";
  }
  return key;
}

const GITHUB_CONFIG = {
  owner: 'japiohopman',
  repo: 'artificer',
  branch: 'main',
  dataPath: 'public/data/audioIndex.json'
};

async function getFile(path: string) {
  try {
    const { data } = await octokit.rest.repos.getContent({
      owner: GITHUB_CONFIG.owner,
      repo: GITHUB_CONFIG.repo,
      path,
      ref: GITHUB_CONFIG.branch
    });
    return data;
  } catch (error: any) {
    if (error.status === 404) return null;
    throw error;
  }
}

async function updateFile(path: string, content: Buffer | string, message: string, sha?: string) {
  const base64Content = Buffer.isBuffer(content) 
    ? content.toString('base64') 
    : Buffer.from(content).toString('base64');
  
  let fileSha = sha;
  if (!fileSha) {
    const existingFile: any = await getFile(path);
    if (existingFile) {
      fileSha = existingFile.sha;
    }
  }

  const params: any = {
    owner: GITHUB_CONFIG.owner,
    repo: GITHUB_CONFIG.repo,
    path,
    message,
    content: base64Content,
    branch: GITHUB_CONFIG.branch
  };

  if (fileSha) {
    params.sha = fileSha;
  }

  await octokit.rest.repos.createOrUpdateFileContents(params);
}

function sanitizeEnvValue(val: string | undefined): string {
  if (!val) return "";
  let clean = val.trim();
  // Strip any wrapping single or double quotes
  if ((clean.startsWith('"') && clean.endsWith('"')) || (clean.startsWith("'") && clean.endsWith("'"))) {
    clean = clean.slice(1, -1);
  }
  return clean.trim();
}

const httpsAgent = new https.Agent({
  rejectUnauthorized: true, // Recommended for production, but bridge uses self-signed
});

// Since we know the bridge might use a custom CA or self-signed cert, we'll use a more permissive agent for local
const localHttpsAgent = new https.Agent({
  rejectUnauthorized: false
});

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "dummy-key",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cookieSession({
  name: 'session',
  keys: [process.env.SESSION_SECRET || 'arcane-ambiante-secret'],
  maxAge: 24 * 60 * 60 * 1000, // 24 hours
  secure: false, // Set to true if using HTTPS on the server itself
  sameSite: 'lax'
}));

// API Routes
app.get("/api/auth/hue/url", (req, res) => {
  const clientId = sanitizeEnvValue(process.env.HUE_CLIENT_ID);
  const appId = sanitizeEnvValue(process.env.HUE_APP_ID);
  
  if (!clientId || !appId) {
    return res.status(500).json({ error: "Hue credentials not configured in environment" });
  }

  const redirectUri = `${process.env.APP_URL || `http://localhost:${PORT}`}/auth/callback`;
  const state = Math.random().toString(36).substring(7);
  
  const params = qs.stringify({
    client_id: clientId,
    appid: appId,
    deviceid: "arcane-ambiance-app",
    devicetype: "Arcane Ambiance",
    response_type: "code",
    state: state
  });

  const url = `https://api.meethue.com/v2/oauth2/authorize?${params}`;
  res.json({ url });
});

app.get("/auth/callback", async (req, res) => {
  const { code, state } = req.query;
  const clientId = sanitizeEnvValue(process.env.HUE_CLIENT_ID);
  const clientSecret = sanitizeEnvValue(process.env.HUE_CLIENT_SECRET);

  if (!code) {
    return res.status(400).send("No code provided");
  }

  try {
    const authHeader = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    
    const response = await axios.post("https://api.meethue.com/v2/oauth2/token", 
      qs.stringify({
        grant_type: "authorization_code",
        code
      }),
      {
        headers: {
          "Authorization": `Basic ${authHeader}`,
          "Content-Type": "application/x-www-form-urlencoded"
        }
      }
    );

    const data = response.data;
    
    if (data.access_token) {
      req.session!.hueToken = data.access_token;
      req.session!.hueRefreshToken = data.refresh_token;
      
      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Hue connected successfully! You can close this window.</p>
          </body>
        </html>
      `);
    } else {
      res.status(400).json(data);
    }
  } catch (error: any) {
    console.error("Auth callback error:", error.message);
    res.status(500).send("Internal Server Error: " + error.message);
  }
});

app.get("/api/hue/status", (req, res) => {
  res.json({ connected: !!req.session?.hueToken });
});

app.get("/api/health/arcane", async (req, res) => {
  const status: any = {
    github: { connected: false, repo: "japiohopman/artificer" },
    elevenlabs: { keys: ELEVENLABS_KEYS.length, status: "unchecked" }
  };

  try {
    // Check GitHub
    const { data: user } = await octokit.rest.users.getAuthenticated();
    status.github.connected = true;
    status.github.user = user.login;
    
    // Check repo access
    await octokit.rest.repos.get({
      owner: "japiohopman",
      repo: "artificer"
    });
    status.github.repoAccess = true;
  } catch (e: any) {
    status.github.error = e.message;
  }

  try {
    status.elevenlabs.accounts = [];
    for (let i = 0; i < ELEVENLABS_KEYS.length; i++) {
        try {
            const elRes = await axios.get("https://api.elevenlabs.io/v1/user/subscription", {
                headers: { "xi-api-key": ELEVENLABS_KEYS[i] }
            });
            status.elevenlabs.accounts.push({
                index: i,
                status: "active",
                tier: elRes.data.tier,
                character_count: elRes.data.character_count,
                character_limit: elRes.data.character_limit
            });
        } catch (err: any) {
            const isPermissionError = err.response?.data?.detail?.status === "missing_permissions";
            status.elevenlabs.accounts.push({
                index: i,
                status: isPermissionError ? "active (restricted)" : "error",
                error: isPermissionError ? "Key works for generation but missing user_read permission." : err.message
            });
        }
    }
    status.elevenlabs.status = ELEVENLABS_KEYS.length > 0 ? "active" : "missing_keys";
  } catch (e: any) {
    status.elevenlabs.status = "error";
    status.elevenlabs.error = e.message;
  }

  res.json(status);
});

// Arcane Audio Routes
app.get('/api/bridge/requests', async (req, res) => {
    console.log(`[Server ${new Date().toISOString()}] GET /api/bridge/requests hit`);
    try {
        const filePath = path.join(process.cwd(), 'bridge', 'AUDIO_REQUESTS.json');
        console.log("[Server] Reading requests from:", filePath);
        const data = await fs.readFile(filePath, 'utf-8');
        res.json(JSON.parse(data));
    } catch (error) {
        console.error('Error reading bridge requests:', error);
        res.status(500).json({ error: 'Failed to fetch bridge requests' });
    }
});

app.get('/api/audio/index', async (req, res) => {
    try {
      const file: any = await getFile(GITHUB_CONFIG.dataPath);
      if (!file) return res.json({ sounds: {} });
      const content = Buffer.from(file.content, 'base64').toString('utf-8');
      res.json(JSON.parse(content));
    } catch (error) {
      console.error('Error fetching audio index:', error);
      res.status(500).json({ error: 'Failed to fetch audio index' });
    }
});

app.get('/api/audio/list/:category', async (req, res) => {
    try {
        const { category } = req.params;
        // Map category to the directory structure in the artificer repo
        const path = `public/assets/sounds/${category}`;
        const data: any = await getFile(path);
        
        if (!data) return res.json([]);
        
        // Octokit.repos.getContent returns an array of objects for directories
        const items = Array.isArray(data) ? data : [];
        
        const files = items
            .filter((item: any) => item.type === 'file' && (item.name.endsWith('.wav') || item.name.endsWith('.mp3')))
            .map((item: any) => ({
                name: item.name,
                url: item.download_url, // This is the raw GitHub content URL
                path: item.path
            }));
            
        res.json(files);
    } catch (error) {
        console.error('Error listing repository category:', error);
        res.status(500).json({ error: 'Failed to list repository assets' });
    }
});

app.post('/api/audio/generate-voice', async (req, res) => {
    const { text, voiceId: rawVoiceId, settings, accountIndex } = req.body;
    const voiceId = (rawVoiceId || "").trim();
    const apiKey = getElevenLabsKey(accountIndex);

    try {
      console.log(`[ElevenLabs] Generation Request: Voice=${voiceId}, Account=${accountIndex + 1}, TextLen=${text?.length}`);

      if (!voiceId) {
        console.error('[ElevenLabs] Rejecting: Missing voiceId');
        return res.status(400).json({ error: 'voiceId is required' });
      }

      if (!apiKey) {
        console.error(`[ElevenLabs] Rejecting: Missing API key for account ${accountIndex + 1}`);
        return res.status(500).json({ error: 'Missing ElevenLabs API key' });
      }

      const url = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}?output_format=mp3_44100_128`;
      console.log(`[ElevenLabs] URL: ${url}`);

      const response = await axios({
        method: 'post',
        url,
        data: {
          text,
          model_id: 'eleven_multilingual_v2',
          voice_settings: settings
        },
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      });

      res.set('Content-Type', 'audio/mpeg');
      res.send(Buffer.from(response.data));

    } catch (error: any) {
      const status = error.response?.status || 500;
      const errorData = error.response?.data;
      
      let detail = error.message;
      
      // Handle Buffer-based error payloads (common with responseType: arraybuffer)
      if (errorData) {
        if (errorData instanceof ArrayBuffer || Buffer.isBuffer(errorData)) {
          try {
            const text = Buffer.from(errorData as any).toString('utf-8');
            const parsed = JSON.parse(text);
            detail = parsed.detail?.message || parsed.detail || parsed.message || text;
          } catch (e) {
            detail = `Binary error payload: ${error.message}`;
          }
        } else {
          detail = typeof errorData === 'object' ? JSON.stringify(errorData) : errorData;
        }
      }

      console.error(`[ElevenLabs] Error ${status}:`, detail);
      
      const maskedKey = apiKey ? `${apiKey.slice(0, 4)}... (len: ${apiKey.length})` : "NONE";
      
      res.status(status).json({ 
        error: status === 404 ? 'Voice ID not found' : 'Failed to generate voice', 
        detail: status === 401 ? `${detail} (Used Key: ${maskedKey})` : detail 
      });
    }
});

app.get('/api/audio/history', async (req, res) => {
    try {
        const accountIndex = parseInt(req.query.accountIndex as string || "0");
        const apiKey = getElevenLabsKey(accountIndex);

        if (!apiKey) {
            return res.status(500).json({ error: 'Missing ElevenLabs API key' });
        }

        const response = await axios.get("https://api.elevenlabs.io/v1/history", {
            headers: { "xi-api-key": apiKey }
        });

        res.json(response.data);
    } catch (error: any) {
        console.error('[ElevenLabs] History fetch error:', error.message);
        res.status(error.response?.status || 500).json({ error: 'Failed to fetch ElevenLabs history' });
    }
});

app.get('/api/audio/history/:id/audio', async (req, res) => {
    const { id } = req.params;
    const accountIndex = parseInt(req.query.accountIndex as string || "0");
    const apiKey = getElevenLabsKey(accountIndex);

    try {
        console.log(`[ElevenLabs] History Audio Fetch: ID=${id}, Account=${accountIndex + 1}`);

        if (!apiKey) {
            console.error('[ElevenLabs] Rejecting: Missing API key');
            return res.status(500).json({ error: 'Missing ElevenLabs API key' });
        }

        const response = await axios({
            method: 'get',
            url: `https://api.elevenlabs.io/v1/history/${id}/audio`,
            headers: { 'xi-api-key': apiKey },
            responseType: 'arraybuffer'
        });

        const buffer = Buffer.from(response.data);
        console.log(`[ElevenLabs] Successfully fetched history audio: ${buffer.length} bytes, Header: ${buffer.slice(0, 16).toString('hex')}`);
        res.set('Content-Type', 'audio/mpeg');
        res.send(buffer);
    } catch (error: any) {
        console.error('[ElevenLabs] History audio fetch error:', error.message);
        res.status(error.response?.status || 500).json({ error: 'Failed to fetch history audio' });
    }
});

app.post('/api/audio/generate-sfx', async (req, res) => {
    try {
      const { text, duration_seconds, prompt_influence, loop, accountIndex } = req.body;
      const apiKey = getElevenLabsKey(accountIndex);

      if (!apiKey) {
        console.error('SFX generation error: missing ElevenLabs API key');
        return res.status(500).json({ error: 'Missing ElevenLabs API key' });
      }
  
      const response = await axios({
        method: 'post',
        url: `https://api.elevenlabs.io/v1/sound-generation`,
        data: {
          text,
          duration_seconds: duration_seconds || 5,
          prompt_influence: prompt_influence || 0.3,
          model_id: 'eleven_text_to_sound_v2',
          loop: loop || false
        },
        headers: {
          'xi-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        responseType: 'arraybuffer'
      });
  
      res.set('Content-Type', 'audio/wav');
      res.send(Buffer.from(response.data));
    } catch (error: any) {
      console.error('SFX generation error:', error.message);
      res.status(500).json({ error: 'Failed to generate SFX' });
    }
});

app.post("/api/gemini/optimize-sound-prompt", async (req, res) => {
  const { prompt, category } = req.body;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `You are an Audio Engineering specialist. Your task is to optimize a descriptive sound prompt for the ElevenLabs Text-to-Sound model.

      Original Description: "${prompt}"
      Target Category: "${category}"

      Requirements:
      - Use technical audio terminology (e.g., frequency range, reverb characteristics, spatial positioning, dynamic range).
      - If category is 'ambient' or 'weather', emphasize loop-friendly textures.
      - Keep it concise but highly descriptive for an AI model.
      - Return ONLY the optimized prompt string.`,
    });

    const optimizedPrompt = (response.text ?? "").trim();
    res.json({ optimizedPrompt });
  } catch (error: any) {
    console.error("Optimization error:", error.message || error);
    res.status(500).json({ error: "Failed to optimize prompt", detail: error.message || String(error) });
  }
});

app.post("/api/gemini/enhance-voice-prompt", async (req, res) => {
  const { prompt, style, voiceModel } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    console.error("Gemini voice enhancement error: missing GEMINI_API_KEY");
    return res.status(500).json({ error: "Missing GEMINI_API_KEY" });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `You are a voice direction specialist optimizing prompts for ElevenLabs text-to-speech.

      Original line or prompt: "${prompt}"
      Selected voice model id: "${voiceModel || "unspecified"}"
      Voice style preset: "${style || "natural fantasy character"}"

      Improve clarity, expand useful performance details, add emotional and tonal guidance, and make the result suitable for direct voice generation.
      Keep the user's spoken line intact when present.
      Return ONLY the enhanced prompt text.`,
    });

    const enhancedPrompt = (response.text ?? "").trim();
    res.json({ enhancedPrompt });
  } catch (error: any) {
    console.error("Voice enhancement error:", error.message || error);
    res.status(500).json({ error: "Failed to enhance voice prompt", detail: error.message || String(error) });
  }
});

app.post('/api/audio/upload', upload.single('file'), async (req, res) => {
    try {
      const { id, metadata } = req.body;
      const file = req.file;
      if (!file) return res.status(400).json({ error: 'No file uploaded' });

      const soundData = JSON.parse(metadata);
      const category = soundData.category || 'sfx';
      const fileName = file.originalname.endsWith('.wav') ? file.originalname : `${file.originalname}.wav`;
      const filePath = `public/assets/sounds/${category}/${fileName}`;

      // 1. Upload the file to GitHub
      await updateFile(filePath, file.buffer, `Add sound: ${id}`);

      // 2. Update the index
      const indexFile: any = await getFile(GITHUB_CONFIG.dataPath);
      let index = { sounds: {} as any };
      let sha = undefined;
  
      if (indexFile) {
        const content = Buffer.from(indexFile.content, 'base64').toString('utf-8');
        index = JSON.parse(content);
        sha = indexFile.sha;
      }
  
      index.sounds[id] = {
        ...soundData,
        file: filePath,
        meta: {
          ...soundData.meta,
          createdAt: new Date().toISOString()
        }
      };
  
      await updateFile(GITHUB_CONFIG.dataPath, JSON.stringify(index, null, 2), `Update index for: ${id}`, sha);
  
      res.json({ success: true, path: filePath });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: 'Failed to upload sound' });
    }
});

let hueDiscoveryCache: { data: any; timestamp: number } | null = null;
const HUE_DISCOVERY_CACHE_MS = 60_000;

app.get("/api/hue/discover", async (req, res) => {
  if (hueDiscoveryCache && Date.now() - hueDiscoveryCache.timestamp < HUE_DISCOVERY_CACHE_MS) {
    return res.json(hueDiscoveryCache.data);
  }

  try {
    const response = await axios.get("https://discovery.meethue.com", { timeout: 5000 });
    hueDiscoveryCache = { data: response.data, timestamp: Date.now() };
    res.json(response.data);
  } catch (error: any) {
    console.error("Discovery error:", error.response?.status || error.message || error);
    if (error.response) {
      return res.status(error.response.status).json(error.response.data);
    }
    res.status(500).json({ error: "Failed to discover bridges", detail: error.message || String(error) });
  }
});

app.post("/api/hue/proxy", async (req, res) => {
  const { method, path: huePath, body, manual } = req.body;
  
  let url: string;
  let headers: Record<string, string>;

  if (manual && manual.ip && manual.username) {
    url = `https://${manual.ip}/clip/v2${huePath}`;
    headers = {
      "hue-application-key": manual.username,
      "Content-Type": "application/json"
    };
  } else {
    const token = req.session?.hueToken;
    if (!token) return res.status(401).json({ error: "Not connected to Hue Cloud" });
    url = `https://api.meethue.com/route/clip/v2${huePath}`;
    headers = {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    };
  }

  try {
    const response = await axios({
      method: (method || "GET") as any,
      url,
      headers,
      data: body,
      httpsAgent: manual ? localHttpsAgent : httpsAgent,
      timeout: 10000
    });

    res.status(response.status).json(response.data);
  } catch (error: any) {
    console.error("Hue proxy error:", error.message);
    if (error.response) return res.status(error.response.status).json(error.response.data);
    res.status(500).json({ error: "Failed to communicate with Bridge", detail: error.message });
  }
});

app.post("/api/gemini/translate", async (req, res) => {
  const { description } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    console.error("Gemini error: missing GEMINI_API_KEY");
    return res.status(500).json({ error: "Missing GEMINI_API_KEY" });
  }
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `You are a System Architect, translating environment descriptions into Philips Hue lighting parameters and audio generation prompts.
      
      Description: "${description}"
      
      Return a JSON object with:
      {
        "lighting": {
          "color": { "xy": { "x": number, "y": number } },
          "dimming": { "brightness": number (0-100) },
          "dynamics": { "duration": number (transition ms) }
        },
        "sound_forge": {
          "sfx_prompt": "An optimized prompt for an ElevenLabs text-to-sound model to recreate this environment audio",
          "voice_prompt": "Describe technical voice qualities suitable for this mood",
          "category": "ambient" | "weather" | "efx" | "music"
        },
        "explanation": "A professional summary of the technical parameters selected"
      }`,
      config: {
        responseMimeType: "application/json"
      }
    });

    const responseText = response.text ?? "";
    if (!responseText) {
      console.error("Gemini error: empty response text");
      return res.status(500).json({ error: "Empty Gemini response" });
    }

    res.json(JSON.parse(responseText));
  } catch (error: any) {
    console.error("Gemini error:", error.message || error);
    res.status(500).json({ error: "Failed to translate description", detail: error.message || String(error) });
  }
});

let sessionLog: any[] = [];

app.get("/api/session/log", (req, res) => {
  res.json(sessionLog);
});

app.post("/api/hue/execute-tool", async (req, res) => {
    const { name, args, manual } = req.body;
    
    const settings = getHueSettingsForTool(name, args);
    if (!settings) {
      return res.status(400).json({ error: `Unknown tool or invalid arguments: ${name}` });
    }
  
    const targetId = args.target_light_id || args.light_id;
    const manualIp = manual?.ip;
    const manualUsername = manual?.username;
    const isManual = !!manualIp && !!manualUsername;
  
    try {
      if (targetId) {
          let url: string;
          let headers: Record<string, string>;
  
          if (manualIp && manualUsername) {
              url = `https://${manualIp}/clip/v2/resource/light/${targetId}`;
              headers = { "hue-application-key": manualUsername, "Content-Type": "application/json" };
          } else {
              const token = req.session?.hueToken;
              if (!token) return res.status(401).json({ error: "Not connected to Hue Cloud" });
              url = `https://api.meethue.com/route/clip/v2/resource/light/${targetId}`;
              headers = { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" };
          }
  
          await axios({
              method: "PUT",
              url,
              headers,
              data: settings,
              httpsAgent: isManual ? localHttpsAgent : httpsAgent
          });
          
          const logMsg = `DM used ${name}${targetId ? ` on ${targetId}` : ""}`;
          sessionLog.unshift({ id: Math.random().toString(36), message: logMsg, type: 'tool', timestamp: new Date() });
          sessionLog = sessionLog.slice(0, 100);

          res.json({ success: true, tool: name, applied_to: targetId, settings });
      } else {
          const logMsg = `DM used ${name} (Global)`;
          sessionLog.unshift({ id: Math.random().toString(36), message: logMsg, type: 'tool', timestamp: new Date() });
          sessionLog = sessionLog.slice(0, 100);

          res.json({ success: true, tool: name, settings, message: "No target light specified. Apply these settings to all lights." });
      }
    } catch (error: any) {
      console.error("Tool execution error:", error.message);
      res.status(500).json({ error: "Failed to execute tool", detail: error.message });
    }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
